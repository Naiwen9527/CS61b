package bearmaps.proj2ab;

public interface PointSet {
    Point nearest(double x, double y);
}
