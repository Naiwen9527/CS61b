package bearmaps.proj2c;

public enum SolverOutcome {
    SOLVED, TIMEOUT, UNSOLVABLE
}
