/**
 * Created by hug.
 */
public interface Lab5FloorSet {
    void add(double i);
    double floor(double i);
}
